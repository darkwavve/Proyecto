#include "Naves.h"

Naves::Naves()
{

}

Naves::~Naves()
{
    //dtor
}

void Naves::logic(ALLEGRO_KEYBOARD_STATE keyStates)
{

}
